<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Contatos</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f6fa;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #002b5b; /* azul escuro */
      color: white;
      text-align: center;
      padding: 20px;
      font-size: 24px;
    }

    .container {
      max-width: 500px;
      margin: 40px auto;
      padding: 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .contato-item {
      margin: 20px 0;
      font-size: 18px;
      text-align: center;
    }

    a {
      color: #002b5b;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }

    footer {
      text-align: center;
      padding: 15px;
      margin-top: 30px;
      font-size: 14px;
      color: #555;
    }
  </style>
</head>
<body>

  <header>Meus Contatos</header>

  <div class="container">
    <div class="contato-item">📱 WhatsApp: <a href="https://wa.me/5579996517388" target="_blank">(79) 99651-7388</a></div>
    <div class="contato-item">📷 Instagram: <a href="https://instagram.com/eletriza079" target="_blank">@eletriza079</a></div>
    <div class="contato-item">✉️ Email: <a href="mailto:eletrizasegurancaeletronica@gmail.com">eletrizasegurancaeletronica@gmail.com</a></div>
  </div>

  <footer>© 2025 Eletriza </footer>

</body>
</html>
